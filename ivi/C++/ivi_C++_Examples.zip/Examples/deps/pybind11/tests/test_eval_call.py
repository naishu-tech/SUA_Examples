# This file is called from 'test_eval.py'
from __future__ import annotations

if "call_test2" in locals():
    call_test2(y)  # noqa: F821 undefined name
