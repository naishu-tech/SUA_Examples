# 编译方式
"""
cd /home/digilab/SUA_Examples/ivi/C++/Examples/build/
cmake ..
make -j 64
"""